package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Product;
import com.example.demo.Exception.InvalidProductException;
import com.example.demo.Repo.ProductRepo;
import com.example.demo.Request.ProductRequest;
import com.example.demo.Response.ProductResponse;

@Service
public class ProductServiceImp implements ProductService {

	@Autowired
	private ProductRepo productRepo;
	
	@Override
	public ProductResponse addProduct(ProductRequest productRequest) {
		if(productRequest.getProductName() == null || !(productRequest.getProductName() instanceof String)) {
			throw new InvalidProductException("Incomplete/Invalid product name. Provide correct information for product name.");
		}
		if(productRequest.getPrice() == null || !(productRequest.getPrice() instanceof Double)) {
			throw new InvalidProductException("Incomplete/Invalid product price. Provide correct information for price.");
		}
		if(productRequest.getCategory() == null || !(productRequest.getCategory() instanceof String)) {
			throw new InvalidProductException("Incomplete/Invalid product category. Provide correct information for product category.");
		}
		
		Product product = Product.builder()
				.productName(productRequest.getProductName())
				.productDesc(productRequest.getProductDesc())
				.price(productRequest.getPrice())
				.category(productRequest.getCategory())
				.imageUrl(productRequest.getImageUrl())
				.build();
		
		productRepo.save(product);
		return new ProductResponse(product);
	}
	
}
