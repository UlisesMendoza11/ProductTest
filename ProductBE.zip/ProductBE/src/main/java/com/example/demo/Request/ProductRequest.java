package com.example.demo.Request;

import lombok.*;

@Data
@Builder
public class ProductRequest {
	
	private String productName;
	private String productDesc;
	private Double price;
	private String category;
	private String imageUrl;
	
}
