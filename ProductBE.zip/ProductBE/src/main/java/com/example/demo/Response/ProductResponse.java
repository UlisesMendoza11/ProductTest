package com.example.demo.Response;

import lombok.*;

import com.example.demo.Entity.Product;

@Data
@Getter
@Setter
public class ProductResponse {

	private String productName;
	private String description;
	private double price;
	private String category;
	private String imageUrl;
	
	public ProductResponse(Product product) {
		this.productName = product.getProductName();
		this.description = product.getProductDesc();
		this.price = product.getPrice();
		this.category = product.getCategory();
		this.imageUrl = product.getImageUrl();
	}
}
