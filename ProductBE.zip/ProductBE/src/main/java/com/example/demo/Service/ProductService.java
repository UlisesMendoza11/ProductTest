package com.example.demo.Service;

import com.example.demo.Request.ProductRequest;
import com.example.demo.Response.ProductResponse;

public interface ProductService {
	
	ProductResponse addProduct(ProductRequest productRequest);
}
