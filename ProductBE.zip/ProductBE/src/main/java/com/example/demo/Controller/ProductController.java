package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Exception.InvalidProductException;
import com.example.demo.Request.ProductRequest;
import com.example.demo.Response.ProductResponse;
import com.example.demo.Service.ProductService;

@RestController
public class ProductController {

	@Autowired
	private final ProductService productService;
	
	public ProductController(ProductService productService) {
		this.productService = productService;
	}
	
	@PostMapping("/product")
	public ResponseEntity<ProductResponse> addProduct(@RequestBody ProductRequest productRequest) throws InvalidProductException {
		ProductResponse response = productService.addProduct(productRequest);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}
}
